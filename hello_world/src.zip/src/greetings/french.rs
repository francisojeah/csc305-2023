pub fn default_greeting() -> String {
    let message = String::from("Alo");
    message
}

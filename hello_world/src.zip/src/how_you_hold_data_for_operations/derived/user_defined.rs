pub enum Compari {
    Greater,
    Lesser,
    Equals,
}

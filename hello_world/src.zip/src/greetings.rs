pub mod french;
pub mod spanish;

///greeting function simply returns a String
pub fn default_greeting() -> String {
    let message = String::from("Hi");
    message
}
